import React, { Component } from 'react';
import './Login.css';
import { withRouter } from 'react-router';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import video from './static/img/video.mp4';
import axios from 'axios';
import $ from 'jquery';


class Login extends React.Component {
	constructor(props) {
		super(props);
		this.sendFormInformation = this.sendFormInformation.bind(this);
	}
  state = {
    email: '',
    mdp: '',
  }

  onChange = event => {
    event.preventDefault();
    this.setState({
      [event.target.id]: event.target.value,
    });
  }

  clearForm = () => {
    this.setState({
      email: '',
      mdp: '',
    });
  }

  sendFormInformation = (email, mdp) => {
	let formData = new FormData();
	formData.append('email', email);
	formData.append('mdp',mdp);
	alert(email);
    fetch('http://10.2.68.50:5000/auth/login', {
        method: 'POST',
        body: formData
      
    })
  }


  render () {
    const { email, mdp } = this.state;
    return (
	<div>
		<video autoPlay muted loop id="myVideo">
		  <source src={video} type="video/mp4" />
		</video>
		<div id="parent"> 
			<div className="login_container">
				<form id="Form" role="form" onSubmit={() => this.sendFormInformation(email,mdp)}>
					<div className="form-group">
						<h1> Connexion </h1>
						<div className="row">
							<div className="col-sm-8">
								<input type="email" className="form-control" id="email" name="email" placeholder="email" required />
							</div>
						</div>
					</div>
					<div className="form-group">
						<div className="row">
							<div className="col-sm-8">
								<input type="password" className="form-control" id="mdp" name="mdp" placeholder="password" required />
							</div>
						</div>
					</div>
					<div className="form-group">
						<div className="row">
							<div className="col-sm-8">
								<div className="col-sm-offset-2 col-sm-10">
									<div className="auth-button">
										<button 
											type="submit"
											className="auth-button-go"
											id="submit"
											>Soumettre
										</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
    )
  }
}


export default withRouter(Login);
