import React, { Component } from 'react';
import './Register.css';
import { withRouter } from 'react-router';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import video from './static/img/video.mp4';
import axios from 'axios';
import $ from 'jquery';


class Welcome extends React.Component {
	constructor(props) {
		super(props);
		this.sendFormInformation = this.sendFormInformation.bind(this);
	}
  state = {
    phrase: '',

  }

  onChange = event => {
    event.preventDefault();
    this.setState({
      [event.target.id]: event.target.value,
    });
  }

  clearForm = () => {
    this.setState({
		phrase: '',

    });
  }

  sendFormInformation = (phrase) => {
	let formData = new FormData();
	formData.append('phrase', "root");
    fetch('http://10.2.68.50:5000/auth/welcome', {
        method: 'POST',
        body: formData   
    }).then(function(response) {
    return response.json();
	})
  }


  render () {
    const { phrase } = this.state;
    return (
	<div>

		<div id="parent"> 
			<div className="register_container">
				<form id="Form" role="form" onSubmit={() => this.sendFormInformation(phrase)}>
					<input type="text" name="phrase" />
						<button 
							type="submit"
							id="submit"
							>Soumettre
						</button>
				</form>
			</div>
		</div>
	</div>
    )
  }
}


export default withRouter(Welcome);
