import React, { Component } from 'react';
import './Register.css';
import { withRouter } from 'react-router';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import video from './static/img/video.mp4';
import axios from 'axios';
import $ from 'jquery';


class Register extends React.Component {
	constructor(props) {
		super(props);
		this.sendFormInformation = this.sendFormInformation.bind(this);
	}
  state = {
    email: '',
    mdp: '',
	nom:'',
	prenom:'',
	ville:'',
	rue:'',
	cp:'',
	tags:''
  }

  onChange = event => {
    event.preventDefault();
    this.setState({
      [event.target.id]: event.target.value,
    });
  }

  clearForm = () => {
    this.setState({
		email: '',
		mdp: '',
		nom:'',
		prenom:'',
		ville:'',
		rue:'',
		cp:'',
		tags:''
    });
  }

  sendFormInformation = (email, mdp, nom, prenom, ville, cp, rue, tags) => {
	let formData = new FormData();
	formData.append('email', email);
	formData.append('mdp',mdp);
	formData.append('nom',nom);
	formData.append('prenom',prenom);
	formData.append('ville',ville);
	formData.append('cp',cp);
	formData.append('rue',rue);
	formData.append('tags',tags);
    fetch('http://10.2.68.50:5000/auth/register', {
        method: 'POST',
        body: formData   
    })
  }


  render () {
    const { email, mdp, nom, prenom, ville, cp, rue, tags} = this.state;
    return (
	<div>
		<video autoPlay muted loop id="myVideo">
		  <source src={video} type="video/mp4" />
		</video>
		<div id="parent"> 
			<div className="register_container">
				<form id="Form" role="form" onSubmit={() => this.sendFormInformation(email,mdp, nom, prenom, ville, cp, rue, tags)}>
					<div className="form-group">
						<h1> Connexion </h1>
						<div className="row">
							<div className="col-sm-8">
								<input type="text" className="form-control" name="email" placeholder="email" required />
							</div>
						</div>
					</div>
					<div className="form-group">
						<div className="row">
							<div className="col-sm-8">
								<input type="password" className="form-control" name="mdp" placeholder="password" required />
							</div>
						</div>
					</div>
					<div className="form-group">
						<div className="row">
							<div className="col-sm-8">
								<input type="text" className="form-control" name="nom" placeholder="Chirac" required />
							</div>
						</div>
					</div>
					<div className="form-group">
						<div className="row">
							<div className="col-sm-8">
								<input type="text" className="form-control" name="prenom" placeholder="Jacques" required />
							</div>
						</div>
					</div>
					<div className="form-group">
						<div className="row">
							<div className="col-sm-8">
								<input type="text" className="form-control" name="rue" placeholder="86, blvd Hausmann" required />
							</div>
						</div>
					</div>
					<div className="form-group">
						<div className="row">
							<div className="col-sm-8">
								<input type="text" className="form-control" name="ville" placeholder="Paris" required />
							</div>
						</div>
					</div>
					<div className="form-group">
						<div className="row">
							<div className="col-sm-8">
								<input type="text" className="form-control" name="cp" placeholder="75008" required />
							</div>
						</div>
					</div>
					<div className="form-group">
						<div className="row">
							<div className="col-sm-8">
								<input type="text" className="form-control" name="tags" placeholder="Art" required />
							</div>
						</div>
					</div>
					<div className="form-group">
						<div className="row">
							<div className="col-sm-8">
								<div className="col-sm-offset-2 col-sm-10">
									<div className="auth-button">
										<button 
											type="submit"
											name="auth-button-go"
											id="submit"
											>Soumettre
										</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
    )
  }
}


export default withRouter(Register);
