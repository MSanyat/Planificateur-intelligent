import React, { Component } from 'react';
import './App.css';
import { withRouter } from 'react-router';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import video from './static/img/video.mp4';
import { WithContext as ReactTags } from 'react-tag-input';
 
const KeyCodes = {
  comma: 188,
  enter: 13,
};
 
const delimiters = [KeyCodes.comma, KeyCodes.enter];

class Form extends React.Component {
	constructor(props) {
        super(props);
 
        this.state = {
            tags: [],
            suggestions: [
                { id: 'Track', text: 'Track' },{  id: 'Service', text: 'Service' },{  id: 'Boutique', text: 'Boutique' },{  id: 'Boxing', text: 'Boxing' },{  id: 'Theme', text: 'Theme' },{  id: 'Station', text: 'Station' },{  id: 'Playground', text: 'Playground' },
				{ id: 'Hobby', text: 'Hobby' },{  id: 'Fitness', text: 'Fitness' },{  id: 'Comedy', text: 'Comedy' },{  id: 'Public', text: 'Public' },{  id: 'Bookste', text: 'Bookste' },{  id: 'Bistro', text: 'Bistro' },{  id: 'Ballroom', text: 'Ballroom' },
				{ id: 'Gym', text: 'Gym' },{  id: 'Football', text: 'Football' },{  id: 'Cultural', text: 'Cultural' },{  id: 'French', text: 'French' },{  id: 'Joint', text: 'Joint' },{  id: 'Liqu', text: 'Liqu' },{  id: 'Studio', text: 'Studio' },{  id: 'Aquarium', text: 'Aquarium' },
				{ id: 'Marina', text: 'Marina' },{  id: 'Karaoke', text: 'Karaoke' },{  id: 'Pool', text: 'Pool' },{  id: 'Furniture', text: 'Furniture' },{  id: 'Building', text: 'Building' },{  id: 'Skating', text: 'Skating' },{  id: 'Agency', text: 'Agency' },
				{ id: 'Bar', text: 'Bar' },{  id: 'Restaurant', text: 'Restaurant' },{  id: 'Venue', text: 'Venue' },{  id: 'Bakery', text: 'Bakery' },{  id: 'Farmers', text: 'Farmers' },{  id: 'Nightlife', text: 'Nightlife' },{  id: 'Bowling', text: 'Bowling' },
				{ id: 'Landmark', text: 'Landmark' },{  id: 'Ferry', text: 'Ferry' },{  id: 'Athletics', text: 'Athletics' },{  id: 'Non-Profit', text: 'Non-Profit' },{  id: 'Wine', text: 'Wine' },{  id: 'Shop', text: 'Shop' },{  id: 'Dojo', text: 'Dojo' },{  id: 'Art', text: 'Art' },
				{ id: 'Indie', text: 'Indie' },{  id: 'Rest', text: 'Rest' },{  id: 'Gallery', text: 'Gallery' },{  id: 'Planetarium', text: 'Planetarium' },{  id: 'Tag', text: 'Tag' },{  id: 'Rink', text: 'Rink' },{  id: 'Go', text: 'Go' },{  id: 'Spa', text: 'Spa' },
				{ id: 'Outdo', text: 'Outdo' },{  id: 'Event', text: 'Event' },{  id: 'Arts', text: 'Arts' },{  id: 'Cowking', text: 'Cowking' },{  id: 'Jewelry', text: 'Jewelry' },{  id: 'Arcade', text: 'Arcade' },{  id: 'Entertainment', text: 'Entertainment' },
				{ id: 'Museum', text: 'Museum' },{  id: 'Zoo', text: 'Zoo' },{  id: 'Beer', text: 'Beer' },{  id: 'Alley', text: 'Alley' },{  id: 'Stationery', text: 'Stationery' },{  id: 'Diner', text: 'Diner' },{  id: 'Coffee', text: 'Coffee' },{  id: 'Run', text: 'Run' },
				{ id: 'Fountain', text: 'Fountain' },{  id: 'Park', text: 'Park' },{  id: 'Miscellaneous', text: 'Miscellaneous' },{  id: 'Pub', text: 'Pub' },{  id: 'Water', text: 'Water' },{  id: 'Fest', text: 'Fest' },{  id: 'Salsa', text: 'Salsa' },{  id: 'Perfming', text: 'Perfming' },
				{ id: 'Ride', text: 'Ride' },{  id: 'Arena', text: 'Arena' },{  id: 'Palace', text: 'Palace' },{  id: 'School', text: 'School' },{  id: 'Theater', text: 'Theater' },{  id: 'Gaming', text: 'Gaming' },{  id: 'Scenic', text: 'Scenic' },{  id: 'Tapas', text: 'Tapas' },
				{ id: 'Plaza', text: 'Plaza' },{  id: 'Racetrack', text: 'Racetrack' },{  id: 'Tour', text: 'Tour' },{  id: 'Rock', text: 'Rock' },{  id: 'Recding', text: 'Recding' },{  id: 'Gay', text: 'Gay' },{  id: 'Reservoir', text: 'Reservoir' },{  id: 'Dance', text: 'Dance' },
				{ id: 'Fish', text: 'Fish' },{  id: 'Circus', text: 'Circus' },{  id: 'Harb', text: 'Harb' },{  id: 'Amphitheater', text: 'Amphitheater' },{  id: 'Auditium', text: 'Auditium' },{  id: 'Facty', text: 'Facty' },{  id: 'Design', text: 'Design' },{  id: 'Market', text: 'Market' },
				{ id: 'Home', text: 'Home' },{  id: 'Cafe', text: 'Cafe' },{  id: 'Photography', text: 'Photography' },{  id: 'Travel', text: 'Travel' },{  id: 'Castle', text: 'Castle' },{  id: 'Lounge', text: 'Lounge' },{  id: 'Music', text: 'Music' },{  id: 'Cosmetics', text: 'Cosmetics' },
				{ id: 'Stadium', text: 'Stadium' },{  id: 'Provider', text: 'Provider' },{  id: 'Piano', text: 'Piano' },{  id: 'Meeting', text: 'Meeting' },{  id: 'Temple', text: 'Temple' },{  id: 'Lookout', text: 'Lookout' },{  id: 'Used', text: 'Used' },{  id: 'Cocktail', text: 'Cocktail' },
				{ id: 'Farm', text: 'Farm' },{  id: 'Hotel', text: 'Hotel' },{  id: 'Baseball', text: 'Baseball' },{  id: 'Botanical', text: 'Botanical' },{  id: 'Histy', text: 'Histy' },{  id: 'Ste', text: 'Ste' },{  id: 'Laser', text: 'Laser' },{  id: 'Center', text: 'Center' },
				{ id: 'Motcycle', text: 'Motcycle' },{  id: 'Mini', text: 'Mini' },{  id: 'Opera', text: 'Opera' },{  id: 'Science', text: 'Science' },{  id: 'Casino', text: 'Casino' },{  id: 'Volleyball', text: 'Volleyball' },{  id: 'American', text: 'American' },
				{ id: 'Histic', text: 'Histic' },{  id: 'Sculpture', text: 'Sculpture' },{  id: 'BBQ', text: 'BBQ' },{  id: 'Memial', text: 'Memial' },{  id: 'Golf', text: 'Golf' },{  id: 'Concert', text: 'Concert' },{  id: 'Office', text: 'Office' },{  id: 'Field', text: 'Field' },
				{ id: 'House', text: 'House' },{  id: 'Library', text: 'Library' },{  id: 'General', text: 'General' },{  id: 'Martial', text: 'Martial' },{  id: 'College', text: 'College' },{  id: 'Roller', text: 'Roller' },{  id: 'Church', text: 'Church' },{  id: 'Spts', text: 'Spts' },
				{ id: 'Boat', text: 'Boat' },{  id: 'Hockey', text: 'Hockey' },{  id: 'City', text: 'City' },{  id: 'Racecourse', text: 'Racecourse' },{  id: 'Basketball', text: 'Basketball' },{  id: 'Court', text: 'Court' },{  id: 'Space', text: 'Space' },{  id: 'Movie', text: 'Movie' },
				{ id: 'Tennis', text: 'Tennis' },{  id: 'Cemetery', text: 'Cemetery' },{  id: 'Attraction', text: 'Attraction' },{  id: 'Other', text: 'Other' },{  id: 'Convention', text: 'Convention' },{  id: 'Soccer', text: 'Soccer' },{  id: 'Beach', text: 'Beach' },
				{ id: 'Brewery', text: 'Brewery' },{  id: 'Stables', text: 'Stables' },{  id: 'Garden', text: 'Garden' },{  id: 'Pedestrian', text: 'Pedestrian' },{  id: 'Outdos', text: 'Outdos' },{  id: 'Exhibit', text: 'Exhibit' },{  id: 'Crafts', text: 'Crafts' },
				{ id: 'Jazz', text: 'Jazz' },{  id: 'Lab', text: 'Lab' },{  id: 'Skate', text: 'Skate' },{  id: 'Flea', text: 'Flea' },{  id: 'Rental', text: 'Rental' },{  id: 'Hall', text: 'Hall' },{  id: 'Great', text: 'Great' },{  id: 'Rugby', text: 'Rugby' },{  id: 'Room', text: 'Room' },
				{ id: 'Medical', text: 'Medical' },{  id: 'Village', text: 'Village' },{  id: 'Dog', text: 'Dog' },{  id: 'Nightclub', text: 'Nightclub' },{  id: 'Winery', text: 'Winery' },{  id: 'Monument', text: 'Monument' },{  id: 'Neighbhood', text: 'Neighbhood' },
				{ id: 'Bridge', text: 'Bridge' },{  id: 'Kart', text: 'Kart' },{  id: 'Site', text: 'Site' },{  id: 'Club', text: 'Club' },{  id: 'Street', text: 'Street' },{  id: 'Radio', text: 'Radio' },{  id: 'Multiplex', text: 'Multiplex' },{  id: 'Pitch', text: 'Pitch' },{  id: 'Clothing', text: 'Clothing'}
             ]
        };
        this.handleDelete = this.handleDelete.bind(this);
        this.handleAddition = this.handleAddition.bind(this);
        this.handleDrag = this.handleDrag.bind(this);
    }
	handleDelete(i) {
        const { tags } = this.state;
        this.setState({
         tags: tags.filter((tag, index) => index !== i),
        });
    }
 
    handleAddition(tag) {
        this.setState(state => ({ tags: [...state.tags, tag] }));
    }
 
    handleDrag(tag, currPos, newPos) {
        const tags = [...this.state.tags];
        const newTags = tags.slice();
 
        newTags.splice(currPos, 1);
        newTags.splice(newPos, 0, tag);
 
        // re-render
        this.setState({ tags: newTags });
    }
  state = {
    add_dep: '',
    j_dep: '',
    h_dep: '',
    add_arr: '',
    j_arr: '',
    h_arr: '',
    escales: '',
	locomotion: '',
	optimisation: '',
	tags: '',
	t_max: '',
	d_max: '',
	max_escales: '',
  }

  onChange = event => {
    this.setState({
      [event.target.id]: event.target.value,
    });
  }

  clearForm = () => {
    this.setState({
      add_dep: '',
      j_dep: '',
      h_dep: '',
      add_arr: '',
      j_arr: '',
      h_arr: '',
      escales: '',
	  locomotion: '',
	  optimisation: '',
	  tags: '',
	  t_max: '',
	  d_max: '',
	  max_escales: '',
    });
  }

  sendFormInformation = (add_dep, j_dep, h_dep, add_arr, j_arr, h_arr, escales, locomotion, optimisation, tags, d_max, t_max, max_escales) => {
    const { router } = this.props;
    const API_HEADERS_AND_MODE = {
      
      mode: 'no-cors',
    };

    const API_SETTINGS = {
      settings: {
        method: 'GET',
		headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
		add_dep: add_dep,
		j_dep: j_dep,
		h_dep: h_dep,
		add_arr: add_arr,
		j_arr: j_arr,
		h_arr: h_arr,
		escales: escales,
		locomotion: locomotion,
		optimisation: optimisation,
		max_escales: 5,
		t_max: t_max,
		d_max: d_max
      },
        body: undefined
      }
    }

    return fetch('http://10.2.68.50:5000/auth/form/', {
      ...API_HEADERS_AND_MODE,
      ...API_SETTINGS.settings
    }).then(res => {
        console.log(res);
        console.log(res.data);
      })
  }


  render () {
	const { tags, suggestions } = this.state;
    const { add_dep, j_dep, h_dep, add_arr, j_arr, h_arr, escales, locomotion, optimisation, t_max, d_max, max_escales } = this.state;
    return (
	<div>
	<video autoPlay muted loop id="myVideo">
	  <source src={video} type="video/mp4" />
	</video>
	
	<div id="parent"> 
		<div className="form_container">
			<div className="form-group">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="add_dep">Adresse de départ</label>
					<div className="col-sm-8">
						<input type="text" className="form-control" id="add_dep" name="add_dep" required />
					</div>
				</div>
			</div>
			<div className="form-group">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="j_dep">Jour de départ</label>
					<div className="col-sm-8">
						<input type="date" className="form-control" id="j_dep" name="j_dep" required />
					</div>
				</div>
			</div>
			<div className="form-group">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="h_dep">Heure de départ</label>
					<div className="col-sm-8">
						<input type="time" className="form-control" id="h_dep" name="h_dep" required />
					</div>
				</div>
			</div>
			<div className="form-group">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="add_arr">Adresse d'arrivée</label>
					<div className="col-sm-8">
						<input type="text" className="form-control" id="add_arr" name="add_arr" required />
					</div>
				</div>
			</div>
			<div className="form-group">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="j_dep">Jour d'arrivée</label>
					<div className="col-sm-8">
						<input type="date" className="form-control" id="j_arr" name="j_arr" required />
					</div>
				</div>
			</div>
			<div className="form-group">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="h_dep">Heure d'arrivée</label>
					<div className="col-sm-8">
						<input type="time" className="form-control" id="h_arr" name="h_arr" required />
					</div>
				</div>
			</div>
			<div className="form-group">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="max_escales">Nombre maximal d'escales</label>
					<div className="col-sm-8">
						<input type="number" className="form-control" id="max_escales" name="max_escales" required />
					</div>
				</div>
			</div>
			<div className="form-group">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="escales">Escales</label>
					<div className="col-sm-8">
						<input type="text" className="form-control" id="escales" name="escales" required />
					</div>
				</div>
			</div>
			<div className="form-group" data-toogle="buttons">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="locomotion">Moyen de transport</label>
					<div className="col-sm-8">
						<ul className="btn">
							<input type="radio" id="locomotion" name="locomotion" value="driving" />
							<label htmlFor="transport_voiture">Voiture</label>
					
						
							<input type="radio" id="transport_en_commun" name="locomotion" value="transit" />
							<label htmlFor="transport_en_commun">Transport en commun</label>
							
							<input type="radio" id="transport_walking" name="locomotion" value="walking" />
							<label htmlFor="transport_walking">A pied</label>
						</ul>
					</div>
				</div>
			</div>
			<div className="form-group" data-toogle="buttons">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="optimisation">Optimisation</label>
					<div className="col-sm-8">
						<ul className="btn">
							<input type="radio" id="optimisation_distance" name="optimisation" value="distance" />
							<label htmlFor="optimisation_distance">Distance</label>
					
						
							<input type="radio" id="optimisation_time" name="optimisation" value="time" />
							<label htmlFor="optimisation_time">Temps</label>
							
							<input type="radio" id="optimisation_affinity" name="optimisation" value="affinity" />
							<label htmlFor="optimisation_affinty">Affinités</label>
						</ul>
					</div>
				</div>
			</div>
			<div className="form-group">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="tags">Tags</label>
					<div className="col-sm-8">
						<div>
							<ReactTags tags={tags}
								suggestions={suggestions}
								handleDelete={this.handleDelete}
								handleAddition={this.handleAddition}
								handleDrag={this.handleDrag}
								delimiters={delimiters} />
						</div>
					</div>
				</div>
			</div>
			<div className="form-group" data-toogle="buttons">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="t_max">Durée maximale sans pause</label>
					<div className="col-sm-8">
						<ul className="btn">
							<input type="radio" id="t_max" name="t_max" value="0" />
							<label htmlFor="t_max">Sans pause</label>
					
						
							<input type="radio" id="t_max" name="t_max" value="3600" />
							<label htmlFor="t_max">1h00</label>
							
							<input type="radio" id="t_max" name="t_max" value="7200" />
							<label htmlFor="t_max">2h00</label>
							
							<input type="radio" id="t_max" name="t_max" value="10800" />
							<label htmlFor="t_max">3h00</label>
						</ul>
					</div>
				</div>
			</div>
			<div className="form-group" data-toogle="buttons">
				<div className="row">
					<label className="control-label col-sm-2" htmlFor="d_max">Distance maximale sans pause</label>
					<div className="col-sm-8">
						<ul className="btn">
							<input type="radio" id="d_max" name="d_max" value="0" />
							<label htmlFor="d_max">Sans pause</label>
					
						
							<input type="radio" id="d_max" name="d_max" value="100000" />
							<label htmlFor="d_max">100km</label>
							
							<input type="radio" id="d_max" name="d_max" value="200000" />
							<label htmlFor="d_max">200km</label>
							
							<input type="radio" id="d_max" name="d_max" value="300000" />
							<label htmlFor="d_max">300km</label>
						</ul>
					</div>
				</div>
			</div>
			<div className="form-group">
				<div className="row">
					<div className="col-sm-8">
						<div className="col-sm-offset-2 col-sm-10">
							<button type="submit" 
							id="submit"
							onClick={ () => this.sendFormInformation(add_dep, j_dep, h_dep, add_arr, j_arr, h_arr, escales, tags, locomotion, optimisation, t_max, d_max, max_escales) }
							>Soumettre</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
    )
  }
};
export default withRouter(Form);
